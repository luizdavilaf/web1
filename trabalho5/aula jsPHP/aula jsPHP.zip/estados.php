<?php
$estados='
{
    "RS":[{"nome":"Rio Grande","cod":1},
        {"nome":"Pelotas","cod":2},
        {"nome":"Porto Alegre","cod":3}],
    "SC":[{"nome":"Florianópolis","cod":4},
        {"nome":"Chapecó","cod":5},
        {"nome":"Itajai","cod":6}],
    "PR":[{"nome":"Curitiba","cod":4},
        {"nome":"Maringa","cod":5},
        {"nome":"Londrina","cod":6}],
    "SP":[{"nome":"São Paulo","cod":4},
        {"nome":"Registro","cod":5},
        {"nome":"Santos","cod":6}]
}
    ';
    echo $estados;
